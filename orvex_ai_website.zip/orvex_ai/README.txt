ORVEX AI — phone-friendly website demo

WHAT'S INCLUDED
- index.html: responsive ORVEX AI interface with dark navy / electric blue theme
- Working demo interactions and sample replies (not connected to a real AI model)
- Desktop sidebar and Android-friendly mobile navigation

HOW TO PUBLISH FREE FROM YOUR ANDROID PHONE
1. Open https://github.com in Chrome and create/sign into an account.
2. Create a new public repository named: orvex-ai
3. Upload index.html from this ZIP (you may need to extract the ZIP first using your phone's Files app).
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for publishing. The site address is usually https://YOUR-USERNAME.github.io/orvex-ai/

IMPORTANT
This is a static website. The chat shows demo responses and does not call a real AI model.
GitHub Pages hosting can be free for a public repository, but AI APIs and custom domains may cost money.
Never put a private AI API key directly in index.html.
